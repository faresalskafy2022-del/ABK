package com.abk.alkhazandar;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.*;
import java.util.*;

public class MainActivity extends Activity {
  private FirebaseAuth auth; private FirebaseFirestore db; private LinearLayout root; private TextView status;
  private final String appId = "alkhazandar"; private final String appTitle = "مكتبة الخزندار";
  private final String[] kinds = new String[]{"المبيعات اليومية", "الداخل", "الخارج", "دفتر الديون"};
  @Override public void onCreate(Bundle b) { super.onCreate(b); buildUi(); try { FirebaseApp.initializeApp(this); auth=FirebaseAuth.getInstance(); db=FirebaseFirestore.getInstance(); signIn(); } catch(Exception e) { status.setText("تعذر تهيئة Firebase: "+e.getMessage()); } }
  private void buildUi() {
    ScrollView scroll=new ScrollView(this); root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,28,28,28); root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); scroll.addView(root); setContentView(scroll);
    TextView head=new TextView(this); head.setText("ABK\n"+appTitle); head.setTextSize(25); head.setTypeface(null,Typeface.BOLD); head.setGravity(Gravity.CENTER); root.addView(head,new LinearLayout.LayoutParams(-1,-2));
    status=new TextView(this); status.setText("جاري الاتصال..."); status.setTextSize(14); root.addView(status);
    if (false) { addAdminList(); } else { addEntryForm(); }
  }
  private EditText field(String hint) { EditText e=new EditText(this); e.setHint(hint); e.setSingleLine(false); root.addView(e,new LinearLayout.LayoutParams(-1,-2)); return e; }
  private void signIn() { if(auth.getCurrentUser()!=null) { status.setText("متصل بقاعدة البيانات"); if (false) loadAll(); return; } auth.signInAnonymously().addOnSuccessListener(r->{ status.setText("تم الاتصال بقاعدة البيانات"); if (false) loadAll(); }).addOnFailureListener(e->status.setText("فشل الاتصال: "+e.getMessage()+"\nتأكد من تفعيل Anonymous في Firebase.")); }
  private void addEntryForm() {
    TextView label=new TextView(this); label.setText("اختر نوع الحركة"); label.setTextSize(18); root.addView(label);
    Spinner spinner=new Spinner(this); ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,kinds); spinner.setAdapter(adapter); root.addView(spinner);
    EditText amount=field("المبلغ"); amount.setInputType(8194);
    EditText customer=field("اسم الزبون / الجهة (اختياري)");
    EditText note=field("البيان أو الملاحظات");
    Button save=new Button(this); save.setText("حفظ الحركة"); root.addView(save);
    save.setOnClickListener(v->{ String a=amount.getText().toString().trim(); if(a.isEmpty()){amount.setError("اكتب المبلغ");return;} Map<String,Object> row=new HashMap<>(); row.put("appId",appId); row.put("appTitle",appTitle); row.put("type",spinner.getSelectedItem().toString()); row.put("amount",a); row.put("customer",customer.getText().toString().trim()); row.put("description",note.getText().toString().trim()); row.put("createdAt",FieldValue.serverTimestamp()); row.put("createdAtLocal",System.currentTimeMillis());
      db.collection("operations").add(row).addOnSuccessListener(ref->{ status.setText("تم حفظ الحركة بنجاح"); amount.setText(""); customer.setText(""); note.setText(""); }).addOnFailureListener(e->status.setText("لم يتم الحفظ: "+e.getMessage())); });
    Button history=new Button(this); history.setText("عرض آخر الحركات"); root.addView(history); history.setOnClickListener(v->loadOwn());
  }
  private void addAdminList() { TextView t=new TextView(this); t.setText("مراقبة حركات التطبيقات الثلاثة"); t.setTextSize(18); t.setTypeface(null,Typeface.BOLD); root.addView(t); Button refresh=new Button(this); refresh.setText("تحديث الحركات"); root.addView(refresh); refresh.setOnClickListener(v->loadAll()); }
  private void loadOwn() { if(db==null)return; db.collection("operations").whereEqualTo("appId",appId).limit(100).get().addOnSuccessListener(s->showDocs(s,"آخر الحركات")).addOnFailureListener(e->status.setText("تعذر جلب الحركات: "+e.getMessage())); }
  private void loadAll() { if(db==null)return; db.collection("operations").limit(200).get().addOnSuccessListener(s->showDocs(s,"كل حركات ABK")).addOnFailureListener(e->status.setText("تعذر جلب الحركات: "+e.getMessage())); }
  private void showDocs(QuerySnapshot snap,String heading) {
    // احذف نتائج العرض السابقة وأبقِ عناصر الإدخال والعنوان.
    int start=9; while(root.getChildCount()>start) root.removeViewAt(start);
    TextView h=new TextView(this); h.setText(heading+" ("+snap.size()+")"); h.setTextSize(18); h.setTypeface(null,Typeface.BOLD); root.addView(h);
    for(DocumentSnapshot d:snap.getDocuments()) { TextView item=new TextView(this); item.setPadding(8,14,8,14); item.setText("التطبيق: "+d.getString("appTitle")+"\nالنوع: "+d.getString("type")+"\nالمبلغ: "+d.getString("amount")+"\nالزبون: "+d.getString("customer")+"\nالبيان: "+d.getString("description")); root.addView(item); View line=new View(this); line.setBackgroundColor(0xffcccccc); root.addView(line,new LinearLayout.LayoutParams(-1,2)); }
  }
}
